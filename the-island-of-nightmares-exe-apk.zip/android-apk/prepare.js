// Descarga nada: copia three.js desde node_modules a www/lib y reescribe las etiquetas <script>
// para que el juego funcione SIN internet. Ejecutar despues de "npm install".
const fs = require('fs'), path = require('path');
const root = __dirname, htmlPath = path.join(root, 'www', 'index.html');
const lib = path.join(root, 'www', 'lib'), nm = path.join(root, 'node_modules', 'three');
if (!fs.existsSync(nm)) { console.error('Falta three. Ejecuta primero: npm install'); process.exit(1); }
fs.mkdirSync(lib, { recursive: true });
function find(dir, name) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    if (f.isDirectory()) { const r = find(p, name); if (r) return r; }
    else if (f.name === name) return p;
  }
  return null;
}
let html = fs.readFileSync(htmlPath, 'utf8'), n = 0, missing = [];
html = html.replace(/<script src="https:\/\/[^"]*three[^"]*?\/([^\/"]+\.js)"><\/script>/g, (m, file) => {
  const src = file === 'three.min.js' ? path.join(nm, 'build', 'three.min.js') : find(path.join(nm, 'examples', 'js'), file);
  if (!src || !fs.existsSync(src)) { missing.push(file); return m; }
  fs.copyFileSync(src, path.join(lib, file)); n++;
  return '<script src="lib/' + file + '"></script>';
});
fs.writeFileSync(htmlPath, html);
console.log('Listo: ' + n + ' scripts copiados a www/lib' + (missing.length ? ' | NO encontrados: ' + missing.join(', ') : ''));
