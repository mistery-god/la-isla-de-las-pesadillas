const { app, BrowserWindow } = require('electron');
const path = require('path');
function create() {
  const w = new BrowserWindow({
    width: 1280, height: 720, backgroundColor: '#070b0a',
    autoHideMenuBar: true, title: 'The Island of Nightmares',
    webPreferences: { contextIsolation: true }
  });
  w.loadFile(path.join(__dirname, 'www', 'index.html'));
  w.webContents.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && i.key === 'F11') { w.setFullScreen(!w.isFullScreen()); e.preventDefault(); }
  });
}
app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
